import { Component } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admindash',
  templateUrl: './admindash.component.html',
  styleUrls: ['./admindash.component.css']
})
export class AdmindashComponent {
  toggle?:boolean=false;
  u?:string;

  constructor(private serv:MyserviceService,private route:Router){
  }
  ngOnInit()
  {
    this.u=MyserviceService.username
  }

  categorybtn()
  {
      this.toggle=true;
  }

  productbtn()
  {
    this.toggle=false;

  }

 // logoutbtn()
  //{//
    //MyserviceService.login=false;//
    //this.route.navigate(["/signup"]);//
  //}//

}
