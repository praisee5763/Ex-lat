import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategoryComponent } from './categorydetails/category/category.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ListproductComponent } from './productdetails/listproduct/listproduct.component';

import { CustomerpanelComponent } from './customerdashboard/customerpanel/customerpanel.component';
import { RouterModule } from '@angular/router';
import { PagenotfoundComponent } from './pagenotfoundcomp/pagenotfound/pagenotfound.component';
import { FlexLayoutModule } from '@angular/flex-layout';


import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { HttpInterceptorService } from './http-interceptor.service';
import {  HTTP_INTERCEPTORS }    from '@angular/common/http';


import { ProductsComponent } from './products/products.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { AdmindashComponent } from './admindash/admindash.component';
import { MainhomeComponent } from './mainhome/mainhome.component';








@NgModule({
  declarations: [
    AppComponent,
    CategoryComponent,
    ListproductComponent,
    CustomerpanelComponent,
    PagenotfoundComponent,
    SignupComponent,
    SigninComponent,


     ProductsComponent,
    UserloginComponent,
    HomeComponent,
    ContactComponent,
    AdmindashComponent,
    MainhomeComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule,NgxPaginationModule,FormsModule,FlexLayoutModule,
    RouterModule.forRoot([
        //{path:"admin",component:AdminpanelComponent},//


        {path:"userlogin",component:UserloginComponent},
        {path:"customer",component:CustomerpanelComponent},
        { path: 'signin', component: SigninComponent },
        { path: 'signup', component: SignupComponent },
        {path:'mainhome', component:MainhomeComponent},
        {path:'contact',component:ContactComponent},
        {path:'category',component:CategoryComponent},
        {path:'product',component:ProductsComponent},
        {path:'admindash', component:AdmindashComponent},
        //{ path: '', redirectTo: '/signin', pathMatch: 'full' },//
        //{path:"**",component:PagenotfoundComponent},//
        {path:"",component:HomeComponent},
    ])
  ],
  providers: [{   provide: HTTP_INTERCEPTORS,
    useClass: HttpInterceptorService,
    multi: true
}],
  bootstrap: [AppComponent],exports:[RouterModule]
})
export class AppModule { }
