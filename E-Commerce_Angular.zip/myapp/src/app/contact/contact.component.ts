import { Component } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  em:any
  constructor( private srv:MyserviceService){

  }
sendmail() {
  this.srv.mail(this.em).subscribe( Response=>alert ("Mail Send Sucessfully"))
}

}
