export class users
{
id?:number=0;
em?:string;
username?:string;
pwd?:string;
}
