export class product
{
prid?:number=0;
prnm?: any='';
ct_catid?:any=0;
price?:number=0;
descrip?: any ='';
qty?:number=0;
reorder?:number=0;
pic?:Blob;
}
