package com.ecommerce.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,
    USER,
}
