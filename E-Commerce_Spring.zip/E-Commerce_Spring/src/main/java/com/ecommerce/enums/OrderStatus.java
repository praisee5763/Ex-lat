package com.ecommerce.enums;

public enum OrderStatus {

    Pending,
    Submitted
}
