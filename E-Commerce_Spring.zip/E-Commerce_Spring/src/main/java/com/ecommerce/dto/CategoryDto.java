package com.ecommerce.dto;

import lombok.Data;


@Data
public class CategoryDto {

    private Long id;

    private String name;

    private String description;

	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}

	public String getDescription() {
		// TODO Auto-generated method stub
		return getDescription();
	}

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		this.id=id;
		
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub
		this.name=name;
		
	}

	public void setDescription(String description2) {
		// TODO Auto-generated method stub
		this.description=description;
		
	}

}
