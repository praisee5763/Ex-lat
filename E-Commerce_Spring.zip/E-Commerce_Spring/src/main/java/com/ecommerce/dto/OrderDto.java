package com.ecommerce.dto;

import com.ecommerce.enums.OrderStatus;
import lombok.Data;

import java.util.Date;
import java.util.List;


@Data
public class OrderDto {

    private String orderDescription;

    private List<CartItemsDto> cartItems;

    private Long id;

    private Date date;

    private Long amount;

    private String address;

    private OrderStatus status;

    private String payment;

    private String userName;

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		this.id=id;
		
	}

	public void setOrderDescription(String orderDescription2) {
		// TODO Auto-generated method stub
		this.orderDescription=orderDescription;
		
	}

	public void setAddress(String address2) {
		// TODO Auto-generated method stub
		this.address=address;
		
	}

	public void setAmount(Long amount2) {
		// TODO Auto-generated method stub
		this.amount=amount;
		
	}

	public void setDate(Date date2) {
		// TODO Auto-generated method stub
		this.date=date;
		
	}

	public void setPayment(String payment2) {
		// TODO Auto-generated method stub
		this.payment=payment;
		
	}

	public void setStatus(OrderStatus status2) {
		// TODO Auto-generated method stub
		this.status=status;
	}

	public void setUserName(Object name) {
		// TODO Auto-generated method stub
		this.userName=userName;
		
	}

	public void setCartItems(List<CartItemsDto> cartItemsDtos) {
		// TODO Auto-generated method stub
		this.cartItems=cartItems;
		
	}
}
