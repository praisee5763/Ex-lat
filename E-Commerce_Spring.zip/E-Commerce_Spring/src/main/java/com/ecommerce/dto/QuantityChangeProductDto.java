package com.ecommerce.dto;

import lombok.Data;

@Data
public class QuantityChangeProductDto {

    private Long productId;

    private Long userId;

	public Long getUserId() {
		// TODO Auto-generated method stub
		return getUserId();
	}

	public Long getProductId() {
		// TODO Auto-generated method stub
		return getProductId();
	}

}
