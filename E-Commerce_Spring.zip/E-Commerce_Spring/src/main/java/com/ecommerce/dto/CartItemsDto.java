package com.ecommerce.dto;

import lombok.Data;

@Data
public class CartItemsDto {

    private Long id;

    private Long price;

    private Long quantity;

    private Long productId;

    private Long orderId;

    private String productName;

    private byte[] returnedImg;

    private Long userId;

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		this.id=id;
		
	}

	public void setPrice(Long price2) {
		// TODO Auto-generated method stub
		this.price=price;
		
	}

	public void setProductId(Object id2) {
		// TODO Auto-generated method stub
		this.productId=productId;
		
	}

	public void setQuantity(Long quantity2) {
		// TODO Auto-generated method stub
		this.quantity=quantity;
		
	}

	public void setUserId(Object id2) {
		// TODO Auto-generated method stub
		this.userId=userId;
		
	}

	public void setProductName(Object name) {
		// TODO Auto-generated method stub
		this.productName=productName;
		
	}

	public void setReturnedImg(Object img) {
		// TODO Auto-generated method stub
		this.returnedImg=returnedImg;
		
	}

	public Long getUserId() {
		// TODO Auto-generated method stub
		return getUserId();
	}

	public Long getProductId() {
		// TODO Auto-generated method stub
		return getProductId();
	}

}
