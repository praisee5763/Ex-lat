package com.ecommerce.dto;


import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ProductDto {

    private Long id;

    private String name;

    private String rating;

    private Long availableQuantity;

    private Long price;

    private String description;

    private MultipartFile img;

    private byte[] returnedImg;

    private Long categoryId;

    private String categoryName;

	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}

	public String getRating() {
		// TODO Auto-generated method stub
		return getRating();
	}

	public Long getPrice() {
		// TODO Auto-generated method stub
		return getPrice();
	}

	public Long getAvailableQuantity() {
		// TODO Auto-generated method stub
		return getAvailableQuantity();
	}

	public String getDescription() {
		// TODO Auto-generated method stub
		return getDescription();
	}

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		this.id=id;
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	public void setRating(String rating2) {
		// TODO Auto-generated method stub
		this.rating=rating;
		
	}

	public void setAvailableQuantity(Long availableQuantity2) {
		// TODO Auto-generated method stub
		this.availableQuantity=availableQuantity;
		
	}

	public void setPrice(Long price2) {
		// TODO Auto-generated method stub
		this.price=price;
		
	}

	public void setDescription(String description2) {
		// TODO Auto-generated method stub
		this.description=description;
		
	}

	public void setReturnedImg(byte[] img2) {
		// TODO Auto-generated method stub
		this.returnedImg=returnedImg;
	}

	public void setCategoryId(Object id2) {
		// TODO Auto-generated method stub
		this.categoryId=categoryId;
	}

	public void setCategoryName(Object name2) {
		// TODO Auto-generated method stub
		this.categoryName=categoryName;
		
	}

	public void setId(Object id2) {
		// TODO Auto-generated method stub
		this.id=id;
		
	}

	public void setName(Object name2) {
		// TODO Auto-generated method stub
		this.name=name;
		
	}

	public void setPrice1(Long price2) {
		// TODO Auto-generated method stub
		this.price=price;
		
	}

	public void setReturnedImg(Object img2) {
		// TODO Auto-generated method stub
		this.returnedImg=returnedImg;
		
	}

	public Object getImg() {
		// TODO Auto-generated method stub
		return getImg();
	}

	public Object getCategoryId() {
		// TODO Auto-generated method stub
		return getCategoryId();
	}

	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		this.price=price;
		
	}

}
