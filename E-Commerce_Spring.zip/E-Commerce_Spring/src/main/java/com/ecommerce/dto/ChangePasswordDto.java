package com.ecommerce.dto;

import lombok.Data;

@Data
public class ChangePasswordDto {

    private Long id;

    private String oldPassword;

    private String newPassword;

	public Long getId() {
		// TODO Auto-generated method stub
		return getId();
	}

	public CharSequence getOldPassword() {
		// TODO Auto-generated method stub
		return getOldPassword();
	}

	public CharSequence getNewPassword() {
		// TODO Auto-generated method stub
		return getNewPassword();
	}

}
