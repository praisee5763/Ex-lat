package com.ecommerce.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class SecondProductDto {

    private Long id;

    private String name;

    private String rating;

    private Long availableQuantity;

    private Long price;

    private String description;

    private MultipartFile img;

    private byte[] returnedImg;

    private String categoryId;

	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}

	public String getRating() {
		// TODO Auto-generated method stub
		return getRating();
	}

	public Long getAvailableQuantity() {
		// TODO Auto-generated method stub
		return getAvailableQuantity();
	}

	public Long getPrice() {
		// TODO Auto-generated method stub
		return getPrice();
	}

	public String getDescription() {
		// TODO Auto-generated method stub
		return getDescription();
	}

	public String getImg() {
		// TODO Auto-generated method stub
		return getImg();
	}

	public String getCategoryId() {
		// TODO Auto-generated method stub
		return getCategoryId();
	}

}
