package com.ecommerce.dto;

import lombok.Data;

@Data
public class PlaceOrderDto {

    private Long userId;

    private String address;

    private String orderDescription;

    private String payment;

	public Long getUserId() {
		// TODO Auto-generated method stub
		return getUserId();
	}

	public Object getOrderDescription() {
		// TODO Auto-generated method stub
		return getOrderDescription();
	}

	public Object getPayment() {
		// TODO Auto-generated method stub
		return getPayment();
	}

	public Object getAddress() {
		// TODO Auto-generated method stub
		return getAddress();
	}

}
