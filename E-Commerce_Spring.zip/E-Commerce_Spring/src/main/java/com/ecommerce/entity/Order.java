package com.ecommerce.entity;

import com.ecommerce.dto.CategoryDto;
import com.ecommerce.dto.OrderDto;
import com.ecommerce.enums.OrderStatus;
import lombok.Data;
import jakarta.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Data
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String orderDescription;

    private Date date;

    private Long amount;

    private String address;

    private String payment;

    private OrderStatus status;

    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "order")
    private List<CartItems> cartItems;

    public OrderDto getOrderDto() {
        OrderDto orderDto = new OrderDto();
        orderDto.setId(id);
        orderDto.setOrderDescription(orderDescription);
        orderDto.setAddress(address);
        orderDto.setAmount(amount);
        orderDto.setDate(date);
        orderDto.setPayment(payment);
        orderDto.setStatus(status);
        orderDto.setUserName(user.getName());
        return orderDto;
    }

	public void setAmount(long l) {
		// TODO Auto-generated method stub
		this.amount=amount;
		
	}

	public void setUser(User user2) {
		// TODO Auto-generated method stub
		this.user=user;
	}

	public void setStatus(OrderStatus pending) {
		// TODO Auto-generated method stub
		this.status=status;
	}

	public Long getId() {
		// TODO Auto-generated method stub
		return getId();
	}

	public Long getAmount() {
		// TODO Auto-generated method stub
		return getAmount();
	}

	public List<CartItems> getCartItems() {
		// TODO Auto-generated method stub
		return getCartItems();
	}

	public OrderStatus getStatus() {
		// TODO Auto-generated method stub
		return getStatus();
	}

	public void setOrderDescription(Object orderDescription2) {
		// TODO Auto-generated method stub
		this.orderDescription=orderDescription;
		
	}

	public void setDate(Date date2) {
		// TODO Auto-generated method stub
		this.date=date;
	}

	public void setPayment(Object payment2) {
		// TODO Auto-generated method stub
		this.payment=payment;
		
	}

	public void setAddress(Object address2) {
		// TODO Auto-generated method stub
		this.address=address;
		
	}

	public String getOrderDescription() {
		// TODO Auto-generated method stub
		return getOrderDescription();
	}

	public Date getDate() {
		// TODO Auto-generated method stub
		return getDate();
	}

	public String getPayment() {
		// TODO Auto-generated method stub
		return getPayment();
	}

	public String getAddress() {
		// TODO Auto-generated method stub
		return getAddress();
		
	}

	public Category getUser() {
		// TODO Auto-generated method stub
		return getUser();
	}

}
