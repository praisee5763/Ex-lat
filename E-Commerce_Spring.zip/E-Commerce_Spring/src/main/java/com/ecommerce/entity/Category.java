package com.ecommerce.entity;

import com.ecommerce.dto.CategoryDto;
import lombok.Data;
import jakarta.persistence.*;

@Entity
@Data
@Table(name = "categories")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Lob
    @Column(name = "description")
    private String description;

    public void getCategoryEntity(CategoryDto categoryDto) {
        this.name = categoryDto.getName();
        this.description = categoryDto.getDescription();
    }

    public CategoryDto getCategoryDto() {
        CategoryDto categoryDto = new CategoryDto();
        categoryDto.setId(id);
        categoryDto.setName(name);
        categoryDto.setDescription(description);
        return categoryDto;
    }

	public Long getId() {
		// TODO Auto-generated method stub
		return getId();
	}

	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub
		this.name=name;
		
	}

	public void setDescription(String description2) {
		// TODO Auto-generated method stub
		this.description=description;
		
	}

	public String getDescription() {
		// TODO Auto-generated method stub
		return getDescription();
	}

	public void setId(Object categoryId) {
		// TODO Auto-generated method stub
		this.id=id;
		
	}

}
